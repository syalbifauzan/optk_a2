<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_list = "localhost";
$database_list = "bkpbanj1_pest";
$username_list = "bkpbanj1";
$password_list = "rahasiabanget";
$list = mysql_pconnect($hostname_list, $username_list, $password_list) or trigger_error(mysql_error(),E_USER_ERROR); 
?>